import { NaPipe } from './na.pipe';

describe('NaPipe', () => {
  it('create an instance', () => {
    const pipe = new NaPipe();
    expect(pipe).toBeTruthy();
  });
});
