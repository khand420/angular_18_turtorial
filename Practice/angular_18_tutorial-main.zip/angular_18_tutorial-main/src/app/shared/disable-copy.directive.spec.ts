import { DisableCopyDirective } from './disable-copy.directive';

describe('DisableCopyDirective', () => {
  it('should create an instance', () => {
    const directive = new DisableCopyDirective();
    expect(directive).toBeTruthy();
  });
});
